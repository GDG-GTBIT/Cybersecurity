Can you try to find out the flag from all this gibberish?

Here's a clue: 
"What's in a name?" - Shakespeare

Happy Hunting (winkies)


P.S. The flag format is GDSC_CTF{}